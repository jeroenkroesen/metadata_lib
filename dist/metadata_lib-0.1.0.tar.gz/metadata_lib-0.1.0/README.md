# Metadata_Tooling
Metadata is used to orchestrate the dataplatform pipelines
