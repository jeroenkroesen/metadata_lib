# Metadata_Lib
Metadata is used to orchestrate the dataplatform pipelines

To install this library using `pip`:
1. USE A VIRTUAL ENV!
2. Run the command:

```bash
pip install git+ssh://git@github.com/jeroenkroesen/metadata_lib.git@main
```
